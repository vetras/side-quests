const express = require('express');
const app = express();
const mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "pa55w0rd"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});

app.use(express.json());

app.get('/', (req, res) => {

    res.send('Test');

});

app.get('/:testparam', (req, res) => {

    res.status(404).send(req.params.testparam);

});


app.listen(3010, () => {
    console.log('Listening in port');
})

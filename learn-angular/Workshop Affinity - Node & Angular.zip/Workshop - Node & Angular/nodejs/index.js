const EventEmitter = require('events');

const myEmitter = new EventEmitter();

let m = 0;
myEmitter.on('event', () => {
  console.log(++m);
});
myEmitter.emit('event');

myEmitter.emit('event');
